SA_sponsors = {
	["A"] = "Official Developer of SoundAlerter",
	["B"] = "Official Sponsor of SoundAlerter",
	["C"] = "Official Contributer of SoundAlerter",
--devs
	["Trolollolol"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
	--Warsong
	["Trollolloll"] = { ["Realm"] = "Warsong (Pure PvP)", ["Type"] = "A" },
	--Sargeras
	["Trollollollo"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
	["Trollololool"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
	["Troolololol"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
	["Ammonia"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
--	["Trolollolol"] = { ["Realm"] = "Neltharion x12", ["Type"] = "A" },
--sponsors
--contributers
	--Warsong
	["Shaquetta"] = { ["Realm"] = "Warsong (Pure PvP)", ["Type"] = "C" },
	["Hotslock"] = { ["Realm"] = "Warsong (Pure PvP)", ["Type"] = "C" },
	--Neltharion
	["Drterror"] = { ["Realm"] = "Neltharion x12", ["Type"] = "C" },
	["Horrorshaman"] = { ["Realm"] = "Neltharion x12", ["Type"] = "C" },
	["Cheaptrick"] = { ["Realm"] = "Neltharion x12", ["Type"] = "C" },
	["Zerodeath"] = { ["Realm"] = "Neltharion x12", ["Type"] = "C" },
	--Frostwolf
	["Clov"] = { ["Realm"] = "Frostwolf x3", ["Type"] = "C" },
	--Deathwing
	["Jeuriess"] = { ["Realm"] = "Deathwing x12", ["Type"] = "C" }
	}
